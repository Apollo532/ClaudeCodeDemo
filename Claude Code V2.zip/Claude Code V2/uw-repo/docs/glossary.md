# Glossary

Plain-English definitions of the insurance terms used in this project.

- **Policy** — the insurance contract for one insured party. Here: a row in the
  `policies` table.
- **Insured / insured name** — the party being covered.
- **Sum insured** — the maximum amount the policy will pay. Used as the basis for
  the premium.
- **Trade** — what the insured does (e.g. `bakery`, `warehouse`). Affects the base
  rate.
- **Territory** — where the risk sits (e.g. `UK`, `EU`). Affects the base rate.
- **Base rate** — a small percentage applied to the sum insured to get a starting
  premium. Looked up by trade and territory in `sql/rating_factors.sql`.
- **Loading** — an increase to the premium for extra risk (e.g. a claims-history
  loading when the insured has had claims recently).
- **Technical premium** — the premium the rating calculation produces, before tax.
- **IPT (Insurance Premium Tax)** — UK tax added on top of the technical premium.
- **Gross premium / GWP (gross written premium)** — technical premium plus IPT; the
  total the insured pays.
- **Claim** — a request for payment under a policy after a loss. Here: a row in the
  `claims` table.
- **Date of loss** — the date the loss happened.
- **Incurred loss** — the total cost of a claim (paid plus outstanding estimate).
- **Loss ratio** — total incurred losses divided by gross premium. A key measure of
  how a book of business is performing. Under 100% means premium exceeded losses.
- **Bordereau** — a spreadsheet listing many policies or claims, sent periodically
  (e.g. monthly) by a broker or coverholder. Here: `data/claims_bordereau.csv`.
- **Referral** — a case that must be sent to an underwriter for a decision rather
  than handled automatically. Here: any single claim over £100,000.
