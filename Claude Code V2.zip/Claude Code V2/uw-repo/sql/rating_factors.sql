-- Rating factors: base rate by trade and territory, plus the claims-history loading.
-- Controlled data. Do not edit directly (see CLAUDE.md).
-- Rates are expressed as a percentage of the sum insured.

create table if not exists rating_factors (
    trade       text not null,
    territory   text not null,
    base_rate   real not null,   -- percent of sum insured, e.g. 0.15 = 0.15%
    primary key (trade, territory)
);

insert into rating_factors (trade, territory, base_rate) values
    ('bakery',    'UK', 0.18),
    ('bakery',    'EU', 0.22),
    ('warehouse', 'UK', 0.12),
    ('warehouse', 'EU', 0.15),
    ('office',     'UK', 0.08),
    ('office',     'EU', 0.10),
    ('workshop',   'UK', 0.20),
    ('workshop',   'EU', 0.25),
    ('restaurant', 'UK', 0.175),
    ('restaurant', 'EU', 0.20);

create table if not exists claims_history_loading (
    claims_last_3_years   integer not null primary key,
    loading               real not null   -- multiplier applied to the technical premium
);

insert into claims_history_loading (claims_last_3_years, loading) values
    (0, 1.00),
    (1, 1.10),
    (2, 1.25),
    (3, 1.50);
