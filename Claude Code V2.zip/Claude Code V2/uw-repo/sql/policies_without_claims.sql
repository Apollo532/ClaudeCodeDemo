-- Lists every policy that has had no claims in the last 3 years.
-- Useful for spotting clean risks at renewal.

select
    p.policy_id,
    p.insured_name,
    p.trade,
    p.territory,
    p.sum_insured
from policies as p
where p.policy_id not in (
    select c.policy_id
    from claims as c
    where c.date_of_loss >= date('now', '-3 years')
)
order by p.insured_name;
