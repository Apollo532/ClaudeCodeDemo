"""A couple of simple checks on the premium calculation.

Run:  python -m unittest
"""

import subprocess
import sys
import unittest
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import calculate_premium  # noqa: E402


def setUpModule():
    # Make sure the database exists and is fresh.
    subprocess.run([sys.executable, str(ROOT / "scripts" / "build_db.py")], check=True)


class CalculatePremiumTests(unittest.TestCase):
    def test_simple_policy_has_expected_gross_premium(self):
        result = calculate_premium.calculate("P001")
        self.assertEqual(result["technical_premium"], Decimal("450.00"))
        self.assertEqual(result["ipt"], Decimal("54.00"))
        self.assertEqual(result["gross_premium"], Decimal("504.00"))

    def test_premium_is_rounded_only_once_at_the_end(self):
        # UW-142: premium should be rounded once, at the end. P003 exposes it:
        #   sum insured 150,500, base rate 0.175%, claims-history loading x1.10.
        #   base premium      = 150500 * 0.175 / 100 = 263.375
        #   technical premium = 263.375 * 1.10       = 289.7125 -> 289.71
        #   IPT               = 289.7125 * 0.12      = 34.7655  -> 34.77
        #   gross premium     = 289.7125 + 34.7655   = 324.478  -> 324.48
        # Currently fails: the calculation rounds at each step and returns 289.72 / 324.49.
        result = calculate_premium.calculate("P003")
        self.assertEqual(result["technical_premium"], Decimal("289.71"))
        self.assertEqual(result["ipt"], Decimal("34.77"))
        self.assertEqual(result["gross_premium"], Decimal("324.48"))


if __name__ == "__main__":
    unittest.main()
