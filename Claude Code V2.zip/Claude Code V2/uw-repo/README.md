# uw-repo

Small internal tools for a London market underwriting team:

- work out the premium for a policy, with a line-by-line breakdown;
- run quality checks over a claims bordereau and report the loss ratio and any
  referrals;
- run ad-hoc SQL queries against the policy/claims database.

## Quick start

```
python scripts/build_db.py
python scripts/calculate_premium.py P001
python scripts/check_claims.py
python -m unittest
```

## What's here

| Path | What it is |
| --- | --- |
| `CLAUDE.md` | Project notes for Claude Code |
| `docs/glossary.md` | Plain-English insurance terms, imported into `CLAUDE.md` |
| `docs/CHANGELOG.md` | Notable changes, newest first |
| `underwriting.db` | SQLite database (policies, premiums, claims) |
| `data/claims_bordereau.csv` | A claims bordereau |
| `sql/` | Queries against the database |
| `reviews/` | Code-review reports (created on demand) |
| `scripts/calculate_premium.py` | Work out the premium for one policy |
| `scripts/check_claims.py` | Check the bordereau, work out the loss ratio |
| `scripts/run_query.py` | Run a `.sql` file against the database and print a table |
| `scripts/build_db.py` | (Re)create the database from seed data |
| `tests/` | Test suite |
| `.claude/rules/` | House style for SQL and Python |
| `.claude/skills/` | Saved procedures: `peer-review`, `check-bordereau` |
| `.claude/agents/` | Helpers: `test-case-writer`, `bug-fixer` |
| `.claude/hooks/` | Scripts the hooks run, plus `README.md` explaining each one |
| `.claude/settings.json` | Wires up the hooks and permission rules |

## Notes

- Standard library only — no third-party dependencies.
- `underwriting.db` is generated; run `scripts/build_db.py` to rebuild it.
- Rating factors (`sql/rating_factors.sql`) and the database are controlled data.
  A hook blocks direct edits to them.
