---
name: check-bordereau
description: >
  Run the standard quality checklist over a claims bordereau file (a CSV of
  claims). Use when someone asks to check, validate, review or QA a bordereau, or
  asks about the loss ratio or referrals for a claims file.
---

# Check a claims bordereau

Follow this checklist every time so the review is consistent.

1. Identify the file. Default to `data/claims_bordereau.csv` if none is given.
2. Make sure the database exists: run `python scripts/build_db.py` if
   `underwriting.db` is missing.
3. Run `python scripts/check_claims.py <file>` and read its output.
4. Also open the CSV yourself and sanity-check for anything the script does not
   catch:
   - duplicate `claim_id` values
   - a `status` that is not `paid` or `outstanding`
   - amounts that look implausible (e.g. far larger than the policy's sum insured)
5. Report back in this shape:
   - **Rows with issues** - claim id and the problem, one per line.
   - **Portfolio figures** - clean row count, total incurred loss, total gross
     premium, loss ratio.
   - **Referrals** - any single claim over GBP 100,000, with claim id and policy.
   - **Recommendation** - one line: is this bordereau clean enough to load, or
     does it need to go back to the broker?
6. Do not edit the CSV or the database.
