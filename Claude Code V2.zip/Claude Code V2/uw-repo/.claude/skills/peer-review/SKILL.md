---
name: peer-review
description: >
  Peer-review a file or script and write a review report into reviews/. Use when
  someone asks for a peer review, asks you to review or check a script or query,
  or wants a second pair of eyes and a written write-up before a change ships.
---

# Peer review

Produce a written review report. Do not change any code.

1. Work out what to review — the file(s) the user named, otherwise the scripts in
   `scripts/`.
2. Read those files **and** the house style in `.claude/rules/python.md` and
   `.claude/rules/sql.md`.
3. Look for problems, in this order of importance:
   - **Correctness and crash risks** — unhandled or blank inputs, values that could
     be missing, wrong rounding, off-by-one, a code path that raises instead of
     reporting.
   - **House-style breaches** — anything that goes against the rules files.
   - **Clarity** — unclear names, missing or misleading comments.
   - **Missing tests** — behaviour that isn't covered.
4. Write the report to `reviews/<filename>-review.md` (create the `reviews/`
   folder if it doesn't exist). Use this shape:
   - **Summary** — two lines: is it fine to ship, and the headline issue if not.
   - **Findings** — a numbered list; for each: severity (High / Medium / Low),
     location (`file:line`), what is wrong, and a suggested fix.
   - **What's fine** — a short list of things done well, so the report is balanced.
   - **Recommended next step** — one line.
5. Tell the user where the report was written.
