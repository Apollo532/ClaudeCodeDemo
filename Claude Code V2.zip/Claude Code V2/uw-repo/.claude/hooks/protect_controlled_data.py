"""PreToolUse hook: block edits to controlled data files.

Claude Code passes the tool call as JSON on stdin. If the file being edited is
the database or the rating factors file, we exit 2 to block the action and print
the reason to stderr (which Claude Code shows to the model and the user).
"""

import json
import sys

CONTROLLED = ("underwriting.db", "rating_factors.sql")


def main() -> int:
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8-sig"))
    except (json.JSONDecodeError, ValueError):
        return 0  # nothing we can check; don't get in the way

    path = (payload.get("tool_input") or {}).get("file_path", "")
    normalised = path.replace("\\", "/")

    if any(normalised.endswith(name) for name in CONTROLLED):
        print(
            f"Blocked: '{path}' is controlled data. Rating factors and the "
            f"database are changed through the proper process, not edited "
            f"directly. See CLAUDE.md.",
            file=sys.stderr,
        )
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
