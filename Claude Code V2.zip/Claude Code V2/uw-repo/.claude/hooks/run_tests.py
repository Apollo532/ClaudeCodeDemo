"""Stop hook: run the test suite when Claude finishes responding.

Prints a short pass/fail summary so whoever is driving can see at a glance
whether the last change kept the tests green. Never blocks.
"""

import subprocess
import sys


def main() -> int:
    result = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"],
        capture_output=True,
        text=True,
    )
    lines = (result.stderr or result.stdout).strip().splitlines()
    summary = lines[-1] if lines else "(no output)"
    status = "PASSED" if result.returncode == 0 else "FAILED"
    print(f"Tests {status}: {summary}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
