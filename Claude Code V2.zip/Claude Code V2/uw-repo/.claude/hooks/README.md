# Hooks

`settings.json` is plain JSON and cannot hold comments, so the hooks are
documented here. Each one is a small Python script in this folder, wired up under
the `hooks` key in `.claude/settings.json`.

| Event | Matcher | Script | What it does | Can it block? |
|-------|---------|--------|--------------|---------------|
| `PreToolUse` | `Edit\|Write` | `protect_controlled_data.py` | Blocks any edit to `underwriting.db` or `sql/rating_factors.sql`. Exits 2 with a reason, so the edit never happens. | Yes |
| `PostToolUse` | `Edit\|Write` | `tidy_python.py` | After a `.py` file is edited: formats it with `ruff` if installed, otherwise just checks it still parses. Prints what it did. | No |
| `Stop` | *(all)* | `run_tests.py` | When Claude finishes a response: runs `python -m unittest` and prints a one-line pass/fail summary. | No |

## How a hook receives its input

Claude Code passes a JSON object on stdin describing the tool call. The
`PreToolUse` and `PostToolUse` scripts read `tool_input.file_path` from it to
decide what to do. `run_tests.py` ignores the input and just runs the suite.

## Notes

- On Windows the `command` runs through PowerShell, so the hooks are written as
  standalone Python scripts (`python .claude/hooks/<name>.py`) rather than shell
  one-liners.
- The `statusMessage` field on each hook in `settings.json` is the short text
  shown in the spinner while the hook runs — it doubles as a one-line comment.
- To turn a hook off temporarily, remove its block from `settings.json` (or set
  `disableAllHooks: true` to disable every hook at once).
