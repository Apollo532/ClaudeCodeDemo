"""PostToolUse hook: tidy up a Python file right after Claude edits it.

Runs after every Edit/Write. If the changed file is a .py file:
  - if 'ruff' is installed, format it and auto-fix trivial issues;
  - otherwise, just check that the file still parses.

This hook never blocks. It only prints what it did.
"""

import json
import py_compile
import shutil
import subprocess
import sys


def main() -> int:
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8-sig"))
    except (json.JSONDecodeError, ValueError):
        return 0

    path = (payload.get("tool_input") or {}).get("file_path", "")
    if not path.endswith(".py"):
        return 0

    if shutil.which("ruff"):
        subprocess.run(["ruff", "format", path], check=False)
        subprocess.run(["ruff", "check", "--fix", "--quiet", path], check=False)
        print(f"Tidied {path} with ruff.")
    else:
        try:
            py_compile.compile(path, doraise=True)
            print(f"Checked {path}: parses OK. (Install 'ruff' for auto-formatting.)")
        except py_compile.PyCompileError as exc:
            print(f"Warning: {path} has a syntax error:\n{exc}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
