---
description: House style for SQL in this project
paths:
  - "sql/**/*.sql"
---

# SQL house style

- Start every query with a one-line comment saying, in plain English, what
  question it answers.
- Use lower-case for SQL keywords (`select`, `from`, `where`, `join`).
- Never use `SELECT *`. List the columns you need, one per line when there are
  several.
- Use short, meaningful table aliases (`policies as p`, `claims as c`) and qualify
  every column with its alias.
- Prefer readable formatting: one clause per line, indent sub-queries.
- Do not write `INSERT`, `UPDATE` or `DELETE` against `underwriting.db` or
  `rating_factors` here. Those are controlled data.
