---
description: House style for Python scripts in this project
paths:
  - "scripts/**/*.py"
  - "tests/**/*.py"
---

# Python house style

- Money is handled with `decimal.Decimal`, never `float`.
- Round money **once, at the very end** of a calculation - not at each step.
- Round to whole pennies with `ROUND_HALF_UP`.
- Show amounts to the user as `GBP 1,234.56` (two decimal places, thousands
  separators).
- Keep scripts short and readable. A script should fit on roughly one screen and
  have a short docstring at the top saying how to run it.
- Standard library only. Do not add third-party dependencies.
