"""Run a .sql file against underwriting.db and print the results as a table.

    python scripts/run_query.py sql/policies_without_claims.sql

Only meant for SELECT queries. This project has no sqlite3 command-line tool, so
this is the easy way to try a query.
"""

import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "underwriting.db"


def main(argv: list[str]) -> None:
    if len(argv) != 2:
        raise SystemExit("Usage: python scripts/run_query.py <path-to-.sql>")

    query = Path(argv[1]).read_text(encoding="utf-8")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute(query)

    headers = [description[0] for description in cursor.description]
    rows = cursor.fetchall()
    conn.close()

    widths = [
        max(len(str(headers[i])), *(len(str(row[i])) for row in rows)) if rows else len(headers[i])
        for i in range(len(headers))
    ]
    line = "  ".join(str(headers[i]).ljust(widths[i]) for i in range(len(headers)))
    print(line)
    print("  ".join("-" * widths[i] for i in range(len(headers))))
    for row in rows:
        print("  ".join(str(row[i]).ljust(widths[i]) for i in range(len(headers))))
    print(f"\n{len(rows)} row(s).")


if __name__ == "__main__":
    main(sys.argv)
