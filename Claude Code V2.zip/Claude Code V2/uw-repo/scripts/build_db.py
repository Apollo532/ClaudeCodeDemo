"""Create underwriting.db from seed data.

Run this once before the other scripts, and any time you want a fresh database:

    python scripts/build_db.py
"""

import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "underwriting.db"
RATING_FACTORS_SQL = ROOT / "sql" / "rating_factors.sql"

POLICIES = [
    # policy_id, insured_name, trade, territory, sum_insured, claims_last_3_years
    ("P001", "Baker Street Bakery", "bakery", "UK", 250_000, 0),
    ("P002", "Camden Cold Store", "warehouse", "UK", 1_200_000, 2),
    ("P003", "Borough Market Kitchen", "restaurant", "UK", 150_500, 1),
    ("P004", "Rue Bonaparte Patisserie", "bakery", "EU", 300_000, 3),
    ("P005", "Docklands Admin Ltd", "office", "UK", 150_000, 0),
    ("P006", "Rotterdam Storage BV", "warehouse", "EU", 2_000_000, 1),
]

# policy_id, technical_premium, ipt, gross_premium  (pre-calculated for the loss ratio)
PREMIUMS = [
    ("P001", 450.00, 54.00, 504.00),
    ("P002", 1_800.00, 216.00, 2_016.00),
    ("P003", 289.71, 34.77, 324.48),
    ("P004", 990.00, 118.80, 1_108.80),
    ("P005", 120.00, 14.40, 134.40),
    ("P006", 3_000.00, 360.00, 3_360.00),
]

CLAIMS = [
    # claim_id, policy_id, date_of_loss, amount, status
    ("C001", "P002", "2024-03-11", 45_000.00, "paid"),
    ("C002", "P002", "2024-09-02", 12_500.00, "outstanding"),
    ("C003", "P003", "2023-12-20", 8_000.00, "paid"),
    ("C004", "P004", "2024-01-05", 60_000.00, "paid"),
    ("C005", "P004", "2024-06-18", 150_000.00, "outstanding"),
    ("C006", "P006", "2024-07-30", 22_000.00, "paid"),
]


def main() -> None:
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.executescript(
        """
        create table policies (
            policy_id           text primary key,
            insured_name        text not null,
            trade               text not null,
            territory           text not null,
            sum_insured         integer not null,
            claims_last_3_years integer not null
        );

        create table premiums (
            policy_id         text primary key references policies (policy_id),
            technical_premium real not null,
            ipt               real not null,
            gross_premium     real not null
        );

        create table claims (
            claim_id     text primary key,
            policy_id    text not null references policies (policy_id),
            date_of_loss text,
            amount       real not null,
            status       text not null
        );
        """
    )

    cur.executemany("insert into policies values (?, ?, ?, ?, ?, ?)", POLICIES)
    cur.executemany("insert into premiums values (?, ?, ?, ?)", PREMIUMS)
    cur.executemany("insert into claims values (?, ?, ?, ?, ?)", CLAIMS)

    cur.executescript(RATING_FACTORS_SQL.read_text(encoding="utf-8"))

    conn.commit()
    conn.close()
    print(f"Created {DB_PATH.relative_to(ROOT)} with "
          f"{len(POLICIES)} policies, {len(PREMIUMS)} premiums, {len(CLAIMS)} claims.")


if __name__ == "__main__":
    main()
