"""Reset the uw-repo project to its starting state for a training run.

This lives OUTSIDE the repo on purpose - the repo itself should look like a normal
internal project. Run it from the project root before every rehearsal and before
the real session:

    python setup/reset.py

It:
  - restores the files the session edits live (two scripts, CLAUDE.md and the
    changelog) to their starting versions - the scripts still contain the two
    latent bugs the session fixes;
  - deletes things a demo may have added (a large_claims.sql query, a
    test_check_claims.py test, the reviews/ folder);
  - rebuilds underwriting.db from seed data.
"""

import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "uw-repo"
BASELINE = HERE / "baseline"

RESTORE = {
    "calculate_premium.py": REPO / "scripts" / "calculate_premium.py",
    "check_claims.py": REPO / "scripts" / "check_claims.py",
    "CLAUDE.md": REPO / "CLAUDE.md",
    "CHANGELOG.md": REPO / "docs" / "CHANGELOG.md",
}

REMOVE_IF_PRESENT = [
    REPO / "sql" / "large_claims.sql",
    REPO / "tests" / "test_check_claims.py",
    REPO / "reviews",
]


def main() -> None:
    for name, target in RESTORE.items():
        shutil.copyfile(BASELINE / name, target)
        print(f"Restored {target.relative_to(REPO)}")

    for path in REMOVE_IF_PRESENT:
        if not path.exists():
            continue
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()
        print(f"Removed {path.relative_to(REPO)}")

    subprocess.run([sys.executable, str(REPO / "scripts" / "build_db.py")], check=True)
    print("Reset complete.")


if __name__ == "__main__":
    main()
