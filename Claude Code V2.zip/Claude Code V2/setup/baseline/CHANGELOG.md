# Changelog

Notable changes to the underwriting tools. Newest first.

## 2026-08-19

- `check_claims.py`: unknown policy ids in a bordereau are now reported as an issue
  instead of being silently counted.

## 2026-07-02

- `calculate_premium.py`: added the claims-history loading to the premium
  breakdown output so brokers can see why the premium moved.

## 2026-06-10

- Initial version: premium calculation, claims-bordereau checks, and the
  `run_query.py` helper.
