# Underwriting Tools

Small internal tools for a London market underwriting team: work out the premium
for a policy, and run quality checks over a claims bordereau.

## What this project does

- Stores **policies**, **premiums** and **claims** in a SQLite database
  (`underwriting.db`).
- `scripts/calculate_premium.py` works out the premium for one policy and prints a
  line-by-line breakdown.
- `scripts/check_claims.py` reads a claims bordereau (`data/claims_bordereau.csv`),
  flags any rows that fail a basic quality check, works out the loss ratio, and
  flags large losses for referral.
- `sql/` holds queries against the database; `scripts/run_query.py` runs them.

## Glossary

@docs/glossary.md

## How to run

```
python scripts/build_db.py            # (re)create underwriting.db from seed data
python scripts/calculate_premium.py P001
python scripts/check_claims.py
python scripts/run_query.py sql/policies_without_claims.sql   # run any .sql file
python -m unittest                    # run the tests
```

## Conventions

- Money is handled with `Decimal`, never `float`. Round once, at the very end.
  Show amounts as GBP to 2 decimal places (see `.claude/rules/python.md`).
- SQL follows the house style in `.claude/rules/sql.md`.
- Rating factors live in `sql/rating_factors.sql`. Treat that file and
  `underwriting.db` as controlled data — do not edit them directly.
