"""Work out the premium for one policy and print a line-by-line breakdown.

    python scripts/calculate_premium.py P001

How the premium is built up:
    base premium   = sum insured x base rate (base rate depends on trade + territory)
    technical prem = base premium x claims-history loading
    IPT            = technical premium x 12%
    gross premium  = technical premium + IPT
"""

import sqlite3
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "underwriting.db"

IPT_RATE = Decimal("0.12")
PENNIES = Decimal("0.01")


def money(value: Decimal) -> Decimal:
    """Round a money amount to whole pennies."""
    return value.quantize(PENNIES, rounding=ROUND_HALF_UP)


def gbp(value: Decimal) -> str:
    return f"GBP {value:,.2f}"


def load_policy(policy_id: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    policy = conn.execute(
        "select policy_id, insured_name, trade, territory, sum_insured, claims_last_3_years "
        "from policies where policy_id = ?",
        (policy_id,),
    ).fetchone()
    if policy is None:
        conn.close()
        raise SystemExit(f"No policy found with id {policy_id!r}")

    base_rate = conn.execute(
        "select base_rate from rating_factors where trade = ? and territory = ?",
        (policy["trade"], policy["territory"]),
    ).fetchone()
    loading = conn.execute(
        "select loading from claims_history_loading where claims_last_3_years = ?",
        (min(policy["claims_last_3_years"], 3),),
    ).fetchone()
    conn.close()

    return {
        "policy": policy,
        "base_rate": Decimal(str(base_rate["base_rate"])),
        "loading": Decimal(str(loading["loading"])),
    }


def calculate(policy_id: str) -> dict:
    data = load_policy(policy_id)
    policy = data["policy"]
    sum_insured = Decimal(policy["sum_insured"])

    base_premium = money(sum_insured * data["base_rate"] / Decimal("100"))
    technical_premium = money(base_premium * data["loading"])
    ipt = money(technical_premium * IPT_RATE)
    gross_premium = money(technical_premium + ipt)

    return {
        "policy": policy,
        "base_rate": data["base_rate"],
        "loading": data["loading"],
        "base_premium": base_premium,
        "technical_premium": technical_premium,
        "ipt": ipt,
        "gross_premium": gross_premium,
    }


def print_breakdown(result: dict) -> None:
    policy = result["policy"]
    print(f"Premium breakdown for {policy['policy_id']} - {policy['insured_name']}")
    print(f"  Trade / territory     : {policy['trade']} / {policy['territory']}")
    print(f"  Sum insured           : {gbp(Decimal(policy['sum_insured']))}")
    print(f"  Base rate             : {result['base_rate']}% of sum insured")
    print(f"  Base premium          : {gbp(result['base_premium'])}")
    print(f"  Claims-history loading : x{result['loading']} "
          f"({policy['claims_last_3_years']} claims in last 3 years)")
    print(f"  Technical premium     : {gbp(result['technical_premium'])}")
    print(f"  IPT (12%)             : {gbp(result['ipt'])}")
    print(f"  Gross premium         : {gbp(result['gross_premium'])}")


def main(argv: list[str]) -> None:
    if len(argv) != 2:
        raise SystemExit("Usage: python scripts/calculate_premium.py <policy_id>")
    print_breakdown(calculate(argv[1]))


if __name__ == "__main__":
    main(sys.argv)
