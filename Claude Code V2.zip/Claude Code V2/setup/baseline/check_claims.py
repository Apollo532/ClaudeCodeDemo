"""Check a claims bordereau and report on it.

    python scripts/check_claims.py [path-to-csv]

It does three things:
  1. Lists rows that fail a basic quality check (missing date of loss,
     non-positive amount, unknown policy).
  2. Works out the loss ratio (total incurred loss / total gross premium).
  3. Flags any single claim over the referral threshold.
"""

import csv
import sqlite3
import sys
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "underwriting.db"
DEFAULT_CSV = ROOT / "data" / "claims_bordereau.csv"

REFERRAL_THRESHOLD = Decimal("100000")


def known_policy_ids() -> set[str]:
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("select policy_id from policies").fetchall()
    conn.close()
    return {row[0] for row in rows}


def total_gross_premium() -> Decimal:
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("select sum(gross_premium) from premiums").fetchone()
    conn.close()
    return Decimal(str(row[0]))


def check_row(row: dict, valid_policies: set[str]) -> list[str]:
    problems = []

    if row["policy_id"] not in valid_policies:
        problems.append(f"unknown policy {row['policy_id']!r}")

    try:
        amount = Decimal(row["amount"])
        if amount <= 0:
            problems.append(f"amount is not positive ({row['amount']})")
    except InvalidOperation:
        problems.append(f"amount is not a number ({row['amount']!r})")

    loss_date = date.fromisoformat(row["date_of_loss"])
    if loss_date > date.today():
        problems.append("date of loss is in the future")

    return problems


def main(argv: list[str]) -> None:
    csv_path = Path(argv[1]) if len(argv) > 1 else DEFAULT_CSV
    valid_policies = known_policy_ids()

    good_rows = []
    print(f"Checking {csv_path.name}\n")

    with csv_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            problems = check_row(row, valid_policies)
            if problems:
                print(f"  ISSUE  {row['claim_id']}: {'; '.join(problems)}")
            else:
                good_rows.append(row)

    incurred = sum(Decimal(row["amount"]) for row in good_rows)
    gross_premium = total_gross_premium()
    loss_ratio = incurred / gross_premium * 100

    print(f"\n  Clean rows            : {len(good_rows)}")
    print(f"  Total incurred loss   : GBP {incurred:,.2f}")
    print(f"  Total gross premium   : GBP {gross_premium:,.2f}")
    print(f"  Loss ratio            : {loss_ratio:.1f}%")

    referrals = [r for r in good_rows if Decimal(r["amount"]) > REFERRAL_THRESHOLD]
    if referrals:
        print("\n  Refer to underwriter (single loss over GBP 100,000):")
        for r in referrals:
            print(f"    {r['claim_id']} - policy {r['policy_id']} - GBP {Decimal(r['amount']):,.2f}")


if __name__ == "__main__":
    main(sys.argv)
